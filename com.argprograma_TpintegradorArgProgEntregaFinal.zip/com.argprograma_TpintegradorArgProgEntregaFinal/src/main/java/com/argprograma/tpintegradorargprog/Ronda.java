package com.argprograma.tpintegradorargprog;

import java.util.ArrayList;
import java.util.List;

public class Ronda {

    private int numero;
    private List<Partido> partidos;
    //HashMap <Integer, Partido> map = new HashMap <Integer, Partido> ();
    private List<Persona> personas;
    
    public Ronda(){
        
    }
    
    public Ronda(int num){
        this.numero = num;
        this.partidos = new ArrayList<Partido>();
        this.personas = new ArrayList<Persona>();
    }
    
  

    public void agregarPartido(Partido p1) {
        this.partidos.add(p1);
    }
    
      public void agregarPersona(Persona p1) {
        this.personas.add(p1);
    }
      
        public void quitarPersona(Persona p1) {
        this.personas.remove(p1);
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<Partido> getPartidos() {
        return partidos;
    }

    public void setPartidos(List<Partido> partidos) {
        this.partidos = partidos;
    }

    public List<Persona> getPersonas() {
        return personas;
    }

    
    
}
