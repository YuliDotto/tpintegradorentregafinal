package com.argprograma.tpintegradorargprog;

import java.util.ArrayList;
import java.util.List;

class fase {
    private int numero;
    private List<Ronda> rondas;


   public fase() {
        
   }
   
       public fase(int num){
        this.numero = num;
        this.rondas = new ArrayList<Ronda>();
    }

   public void agregarRonda(Ronda r1) {
        this.rondas.add(r1);
    }
   
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<Ronda> getRondas() {
        return rondas;
    }

    public void setRondas(List<Ronda> rondas) {
        this.rondas = rondas;
    }
   
   
   
   
}


