package com.argprograma.tpintegradorargprog;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.*;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class MiProyecto {

    public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {

        Scanner scn = new Scanner(System.in);
        System.out.println("ingrese la cantidad de puntaje por pronostico acertado: ");
   
        int puntaje;

        puntaje = scn.nextInt();

        System.out.println("ingrese la cantidad de puntos extras por acertar todos los pronosticos de la ronda");
        int puntajeExtraRonda;

        puntajeExtraRonda = scn.nextInt();

        Class.forName("com.mysql.cj.jdbc.Driver");
        String file1 = ("C:\\Users\\Martin\\Desktop\\curso arg programa\\TPINTEGRADORENTREGAFINAL\\Resultados.csv");

        System.out.println("pronostico: ");
        
  
        
        //porcion del codigo que crea las rondas segun el numero en detalle [0]
        HashMap<Integer, Ronda> map = new HashMap<Integer, Ronda>();
        for (String linea : Files.readAllLines(Paths.get(file1))) {
            String[] detalle = linea.split(";");

            int numeroRonda = Integer.parseInt(detalle[0]);
            Ronda r1 = map.get(numeroRonda);

            if (r1 == null) {
                r1 = new Ronda(numeroRonda);
                map.put(numeroRonda, r1);
            }
        }
        
    

        //se crean los partidos y se añaden al hashmap de rondas segun la ronda 1 o 2
        for (String linea : Files.readAllLines(Paths.get(file1))) {
            String[] detalle = linea.split(";");

            //se verifica que los goles sean un numero entero
            if (detalle[2].matches("[0-9]*") && detalle[3].matches("[0-9]*")) {

                String equ1 = detalle[1];
                String equ2 = detalle[4];

                int goleseq1 = Integer.parseInt(detalle[2]);
                int goleseq2 = Integer.parseInt(detalle[3]);

                Partido partido = new Partido(equ1, equ2, goleseq1, goleseq2);

                partido.setIdPartido(Integer.parseInt(detalle[0]));

                //se crea un arraylist de partidos por cada instancia de ronda y se agregan los partidos correspondientes
                for (int r = 1; r <= map.size(); r++) {
                    List<Partido> partidos;
                    partidos = new ArrayList<Partido>();
                    if (map.get(r).getNumero() == partido.getIdPartido()) {
                        partidos.add(partido);
                        map.get(r).agregarPartido(partido);
                    }
                }

            } else {
                System.out.println("los goles no son numeros enteros");
            }
        }

        //creamos las personas desde la base de datos mysql y las referenciamos en un hashmap
        HashMap<Integer, Persona> persMap = new HashMap<Integer, Persona>();

        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tpintegradorfinal3", "root", "admin");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select * from pronosticos");

        while (rs.next()) {
            int cod = rs.getInt(8);
            int key = (cod);
            Persona p1 = persMap.get(key);

            if (p1 == null) {
                p1 = new Persona(key, rs.getString(2));
                persMap.put(key, p1);
            }
        }
        con.close();

        // AGREGAMOS LAS PERSONAS A NUESTRO MAPA REFERENCIADO POR EL MAPA DE PERSONAS ANTERIOR (PARA QUE CREE DISTINTOS OBJETOS PERSONA)
        for (int d = 1; d <= map.size(); d++) {
            for (int t = 1; t <= persMap.size(); t++) {
                Persona pRef = new Persona();
                pRef.setNombre(persMap.get(t).getNombre());
                map.get(d).agregarPersona(pRef);
            }
        }

        //ESTA PARTE DEL CODIGO NOS COMPARA LOS PRONOSTICOS DE LA BASE DE DATOS CON EL ARCHIVO DE PARTIDOS, LOS CALCULA Y LOS VA AGREGANDO A NUESTRO MAPA
        //SEGUN LA RONDA, Y LA PERSONA QUE HIZO EL PRONOSTICO LES AGREGA EL PUNTAJE
        Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/tpintegradorfinal3", "root", "admin");
        Statement stmt2 = con2.createStatement();
        ResultSet rs2 = stmt2.executeQuery("select * from pronosticos");

        while (rs2.next()) {

            String nombre = rs2.getString(2);
            String equipo1 = rs2.getString(3);
            String ganaequipo1 = rs2.getString(4);
            String empate = rs2.getString(5);
            String ganaequipo2 = rs2.getString(6);
            String equipo2 = rs2.getString(7);

            Pronostico pr1 = new Pronostico();

            for (String linea2 : Files.readAllLines(Paths.get(file1))) {
                String[] detalle2 = linea2.split(";");
                //se verifica que los goles sean un numero entero
                if (detalle2[2].matches("[0-9]*") && detalle2[3].matches("[0-9]*")) {

                    String equ1 = detalle2[1];
                    String equ2 = detalle2[4];

                    int goleseq1 = Integer.parseInt(detalle2[2]);
                    int goleseq2 = Integer.parseInt(detalle2[3]);

                    Partido partido = new Partido(equ1, equ2, goleseq1, goleseq2);

                    partido.setIdPartido(Integer.parseInt(detalle2[0]));

                    if (equipo1.equalsIgnoreCase(partido.getEquipo1().getNombre())
                            && equipo2.equalsIgnoreCase(partido.getEquipo2().getNombre())) {
                        pr1.setPartido(partido);
                        if (ganaequipo1.equalsIgnoreCase("x")) {

                            pr1.setEquipo(partido.getEquipo1());

                            pr1.setResultado(ResultadoEnum.GANADOR);
                        } else if (empate.equalsIgnoreCase("x")) {

                            pr1.setResultado(ResultadoEnum.EMPATE);

                        } else if (ganaequipo2.equalsIgnoreCase("x")) {

                            pr1.setEquipo(partido.getEquipo2());
                            pr1.setResultado(ResultadoEnum.GANADOR);
                        }
                    } else {

                    }

                }
            }
            //añadimos el puntaje del pronostico a los objetos persona
            for (int r = 1; r <= map.size(); r++) {
                for (int b = 0; b < map.get(r).getPersonas().size(); b++) {
                    for (int i = 0; i < map.get(r).getPartidos().size(); i++) {
                        if (map.get(r).getPartidos().get(i).getEquipo1().getNombre().equalsIgnoreCase(pr1.getPartido().getEquipo1().getNombre())
                                && map.get(r).getPartidos().get(i).getEquipo2().getNombre().equalsIgnoreCase(pr1.getPartido().getEquipo2().getNombre())
                                && map.get(r).getNumero() == pr1.getPartido().getIdPartido()
                                && map.get(r).getPersonas().get(b).getNombre().equalsIgnoreCase(nombre)) {
                            map.get(r).getPersonas().get(b).agregarPronostico(pr1);
                            map.get(r).getPersonas().get(b).setPronostico(pr1);
                            map.get(r).getPersonas().get(b).setPuntajePersona(pr1.calcularPronostico(puntaje) + map.get(r).getPersonas().get(b).getPuntajePersona());
                            map.get(r).getPersonas().get(b).setPronosticosAcertados(pr1.pronosticoAcertado() + map.get(r).getPersonas().get(b).getPronosticosAcertados());
                        }
                    }
                }
            }
        }
        con2.close();
        
        //se agrega el puntaje extra si la persona acerto todos los resultados
        for (int r = 1; r <= map.size(); r++) {
            for (int b = 0; b < map.get(r).getPersonas().size(); b++) {
                if (map.get(r).getPersonas().get(b).getPronosticos().size() == map.get(r).getPersonas().get(b).getPronosticosAcertados()) {
                    map.get(r).getPersonas().get(b).setPuntajePersona(map.get(r).getPersonas().get(b).getPuntajePersona() + puntajeExtraRonda);
                }
            }
        }

        //el output que nos dice la cantidad de puntos por ronda de cada persona
        for (int r = 1; r <= map.size(); r++) {
            for (int b = 0; b < map.get(r).getPersonas().size(); b++) {
                System.out.println("el puntaje de la ronda " + map.get(r).getNumero() + " de la persona " + map.get(r).getPersonas().get(b).getNombre()
                        + " es de " + map.get(r).getPersonas().get(b).getPuntajePersona()
                        + ", cantidad de pronosticos acertados = " + map.get(r).getPersonas().get(b).getPronosticosAcertados() + " de " + map.get(r).getPersonas().get(b).getPronosticos().size());
            }
        }
        System.out.println("puntaje extra añadido por acertar todos los pronosticos de la ronda = "  + puntajeExtraRonda);
    }
}
